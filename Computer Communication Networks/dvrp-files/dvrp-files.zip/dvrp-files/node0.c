#include <stdio.h>
#include "dvrp.h"

extern int TRACE;
extern int YES;
extern int NO;
extern float clocktime;

int lkcost0[4];		/*The link cost between node 0 and other nodes*/
int spath0[4];			/*The shortest path between node 0 and other nodes*/
struct distance_table 		/*Define distance table*/
{
  int costs[4][4];
} dt0;

/**** Declarations internal to node0  ****/
void printdt0(struct distance_table *dtptr);

/* students to write the following two routines, and maybe some others */

void rtinit0() 
{

}


void rtupdate0(rcvdpkt)
  struct rtpkt *rcvdpkt;
{

}


void printdt0(dtptr)
  struct distance_table *dtptr;
{
  printf("                via     \n");
  printf("   D0 |    1     2    3 \n");
  printf("  ----|-----------------\n");
  printf("     1|  %3d   %3d   %3d\n",dtptr->costs[1][1], dtptr->costs[1][2],dtptr->costs[1][3]);
  printf("dest 2|  %3d   %3d   %3d\n",dtptr->costs[2][1], dtptr->costs[2][2],dtptr->costs[2][3]);
  printf("     3|  %3d   %3d   %3d\n",dtptr->costs[3][1], dtptr->costs[3][2],dtptr->costs[3][3]);
}

void linkhandler0(linkid, newcost)   
  int linkid, newcost;
/* called when cost from 0 to linkid changes from current value to newcost*/
/* You can leave this routine empty if you're not doing the extra credit. If you want */
/* to use this routine, you'll need to change the value of the LINKCHANGE */
/* constant definition in dvrp.c from 0 to 1 */	
{

}


