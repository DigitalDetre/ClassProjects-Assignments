#include <stdio.h>
#include "dvrp.h"

extern int TRACE;
extern int YES;
extern int NO;
extern float clocktime;

int lkcost2[4];		/*the link cost between node 0 and other nodes*/
int spath2[4];		/*the shortest path between node 0 and other nodes*/

struct distance_table /*define distance table*/
{
  int costs[4][4];
} dt2;

/**** Declarations internal to node2  ****/
void printdt2(struct distance_table *dtptr);

/* students to write the following two routines, and maybe some others */
void rtinit2()
{

}


void rtupdate2(rcvdpkt)
  struct rtpkt *rcvdpkt;
{

}


void printdt2(dtptr)
  struct distance_table *dtptr;
  
{
  printf("                via     \n");
  printf("   D2 |    0     1    3 \n");
  printf("  ----|-----------------\n");
  printf("     0|  %3d   %3d   %3d\n",dtptr->costs[0][0], dtptr->costs[0][1],dtptr->costs[0][3]);
  printf("dest 1|  %3d   %3d   %3d\n",dtptr->costs[1][0], dtptr->costs[1][1],dtptr->costs[1][3]);
  printf("     3|  %3d   %3d   %3d\n",dtptr->costs[3][0], dtptr->costs[3][1],dtptr->costs[3][3]);
}

void linkhandler2(linkid, newcost)   
  int linkid, newcost;

/* called when cost from 0 to linkid changes from current value to newcost*/
/* You can leave this routine empty if you're not doing the extra credit. If you want */
/* to use this routine, you'll need to change the value of the LINKCHANGE */
/* constant definition in dvrp.c from 0 to 1 */	
{

}
