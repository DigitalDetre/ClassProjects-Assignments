Compile using the makefile

Run it