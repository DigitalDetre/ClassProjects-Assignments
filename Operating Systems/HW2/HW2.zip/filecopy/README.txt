Use the makefile or use gcc filecopy.c

After filecopy has compiled run in the command line using

./filecopy <input.txt> <copy.txt>

*An input file has been provided in this folder. Use your own if you would like.
**Please note that this code does not account for a copy.txt already existing in the directory. It will not overwrite an existing copy.txt. Please delete copy.txt before running.