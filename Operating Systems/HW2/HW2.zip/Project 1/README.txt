Compile using the makefile or gcc shell.c

Then run using
./shell

A bash-like terminal will appear after a second. Most bash commands will work.
'!!' - Uses the most recent command
'!#' - Where # is a number from 0 - 10, Uses the command in that position in the history
'history' - Lists the recent 10 commands/entered strings
'ls' - Lists all the files in current directory