Compile using the makefile or gcc collatz.c

Then run using
./collatz #
where # is a number